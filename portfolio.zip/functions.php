<?php 
        /**
         * enqueue css and js
         */
    require_once get_template_directory() .'/inc/enq.php';   
        /**
         * setup theme 
         */
    require_once get_template_directory() .'/inc/theme_setup.php';   
        /**
         * menu setup
         */
    require_once get_template_directory() .'/inc/menu.php';   
 
        /**
         * Codestar Framework
         */
    require_once get_template_directory() .'/cs-framework/cs-framework.php';  
       
?>